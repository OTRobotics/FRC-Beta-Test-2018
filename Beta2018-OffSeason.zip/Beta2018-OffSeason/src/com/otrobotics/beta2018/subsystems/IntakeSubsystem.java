package com.otrobotics.beta2018.subsystems;

import com.ctre.phoenix.MotorControl.CAN.TalonSRX;
import com.otrobotics.beta2018.RobotMap;

import edu.wpi.first.wpilibj.command.Subsystem;

public class IntakeSubsystem extends Subsystem{
	public TalonSRX intakePickup = new TalonSRX(RobotMap.intakePickup);
	public TalonSRX intakeDump = new TalonSRX(RobotMap.intakeDump);
	@Override
	protected void initDefaultCommand() {
		// TODO Auto-generated method stub
		
	}
	
	public void runIntakePickup(boolean isSpinning){
		if(isSpinning){
			intakePickup.set(-1.0);
		}else{
			intakePickup.set(0.0);
		}
	}
	
	public void runIntakeDump(boolean isSpinning){
		if(isSpinning){
			intakeDump.set(-1.0);
		}else{
			intakeDump.set(0.0);
		}
	}

}
